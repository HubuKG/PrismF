import pickle

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.layer import *
import math
from .model import BaseModel



class Per_EmbLayer(nn.Module):
    
    def __init__(self, input_size, output_size, dropout=0.0):
        super(Per_EmbLayer, self).__init__()

        self.dropout = nn.Dropout(p=dropout)
        self.bias = nn.Parameter(torch.zeros(input_size), requires_grad=True)
        self.lin = nn.Linear(input_size, output_size, bias=False)

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=0.02)

    def forward(self, x):
        return self.lin(self.dropout(x) - self.bias)


class MuPELayer(nn.Module):
    """Multi-Perspective Enhancement
    """
    def __init__(self, n_pers, layers, dropout=0.0, noise=True):
        super(MuPELayer, self).__init__()

        self.n_pers = n_pers
        self.noisy_gating = noise

        self.perspectives = nn.ModuleList([Per_EmbLayer(layers[0], layers[1], dropout) for i in range(n_pers)])
        self.w_gate = nn.Parameter(torch.zeros(layers[0], n_pers), requires_grad=True)
        self.w_noise = nn.Parameter(torch.zeros(layers[0], n_pers), requires_grad=True)

    def noisy_top_k_gating(self, x, r=None, train=None, noise_epsilon=1e-2):
        clean_logits = x @ self.w_gate
        if self.noisy_gating and train:
            raw_noise_stddev = x @ self.w_noise
            noise_stddev = ((F.softplus(raw_noise_stddev) + noise_epsilon))
            noisy_logits = clean_logits + (torch.randn_like(clean_logits).to(x.device) * noise_stddev)
            logits = noisy_logits
        else:
            logits = clean_logits
        if r is not None:
            gates = F.softmax(logits / torch.sigmoid(r), dim=-1)
        else:
            gates = F.softmax(logits, dim=-1)
        return gates

    def forward(self, x, r=None):
        gates = self.noisy_top_k_gating(x, r, self.training) # (B, n_E)
        perspective_outputs = [self.perspectives[i](x).unsqueeze(-2) for i in range(self.n_pers)] # [(B, 1, D)]
        perspective_outputs = torch.cat(perspective_outputs, dim=-2)
        multiple_outputs = gates.unsqueeze(-1) * perspective_outputs
        return multiple_outputs.sum(dim=-2), perspective_outputs, gates
    


import pickle

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.layer import *

from .model import BaseModel

class PMFusionLayer(nn.Module):
    def __init__(self, in_dim, out_dim, multi, img_dim, txt_dim):
        super(PMFusionLayer, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.multi = multi
        self.img_dim = img_dim
        self.text_dim = txt_dim

        self.modal1_layers = nn.ModuleList([
            nn.Sequential(nn.Dropout(p=0.2), nn.Linear(in_dim, out_dim), nn.ReLU())
            for _ in range(multi)
        ])
        self.modal2_layers = nn.ModuleList([
            nn.Sequential(nn.Dropout(p=0.2), nn.Linear(img_dim, out_dim), nn.ReLU())
            for _ in range(multi)
        ])
        self.modal3_layers = nn.ModuleList([
            nn.Sequential(nn.Dropout(p=0.2), nn.Linear(txt_dim, out_dim), nn.ReLU())
            for _ in range(multi)
        ])

        self.ent_attn = nn.Linear(out_dim, 1, bias=False)
        self.ent_attn.requires_grad_(True)
        
        self.cross_enhance = nn.ModuleList([
            nn.Sequential(
                nn.Linear(out_dim*2, out_dim),
                nn.ReLU(),
                nn.LayerNorm(out_dim)
            ) for _ in range(multi)
        ])
        
        self.temperature = nn.Parameter(torch.tensor([0.01]))
        self.res_weights = nn.Parameter(torch.ones(2))
        
        self.confidence_nets = nn.ModuleList([
            nn.Sequential(
                nn.LayerNorm(out_dim),
                nn.Linear(out_dim, 32),
                nn.GELU(),
                nn.Linear(32, 1),
                nn.Sigmoid()
            ) for _ in range(3)  
        ])

    def forward(self, modal1_emb, modal2_emb, modal3_emb, progress=1.0):
        batch_size = modal1_emb.size(0)
        x_mm = []
        
        for i in range(self.multi):
            
            x_modal1 = self.modal1_layers[i](modal1_emb)
            x_modal2 = self.modal2_layers[i](modal2_emb)
            x_modal3 = self.modal3_layers[i](modal3_emb)
            
            
            cross_feat = self.cross_enhance[i](torch.cat([x_modal2, x_modal3], dim=1))
            enhanced_modal1 = x_modal1 + self.res_weights[0] * cross_feat
            
            
            x_stack = torch.stack((
                enhanced_modal1, 
                x_modal2 * torch.sigmoid(x_modal3.mean(-1, keepdim=True)),
                x_modal3 * torch.sigmoid(x_modal2.mean(-1, keepdim=True))
            ), dim=1)
            
            
            temperature = torch.clamp(self.temperature, min=0.01, max=1.0)
            x_stack = x_stack.requires_grad_(True)  
            attention_scores = self.ent_attn(x_stack) / temperature
            attention_weights = F.softmax(attention_scores.squeeze(-1), dim=-1)
            
            conf_s = self.confidence_nets[0](x_modal1)  
            conf_v = self.confidence_nets[1](x_modal2)  
            conf_t = self.confidence_nets[2](x_modal3)  

            effective_progress = torch.sigmoid(torch.tensor(3 * progress - 1.5))
            base_weights = torch.cat([
                conf_s,
                conf_v * effective_progress,  
                conf_t * effective_progress   
            ], dim=1)  # [B,3]
            
            adjusted_weights = attention_weights * base_weights
            adjusted_weights = adjusted_weights / (adjusted_weights.sum(dim=-1, keepdim=True) + 1e-8)

            residual_ratio = torch.sigmoid(0.8 * (1 - conf_s)) 
            context_vectors = torch.sum(adjusted_weights.unsqueeze(-1) * x_stack, dim=1)
            x_mm.append(context_vectors + residual_ratio * x_modal1)

        x_mm = torch.stack(x_mm, dim=1).mean(dim=1)
        return x_mm, adjusted_weights

    
    def relation_gated_fuse(self, modal1_emb, modal2_emb, modal3_emb, rel):
        batch_size = modal1_emb.size(0)
        x_mm = []
        for i in range(self.multi):
            x_modal1 = self.modal1_layers[i](modal1_emb)
            x_modal2 = self.modal2_layers[i](modal2_emb)
            x_modal3 = self.modal3_layers[i](modal3_emb)
            x_stack = torch.stack((x_modal1, x_modal2, x_modal3), dim=1)
            attention_scores = self.ent_attn(x_stack).squeeze(-1)
            attention_weights = torch.softmax(attention_scores / rel, dim=-1)
            context_vectors = torch.sum(attention_weights.unsqueeze(-1) * x_stack, dim=1)
            x_mm.append(context_vectors)
        x_mm = torch.stack(x_mm, dim=1)
        x_mm = x_mm.mean(1).view(batch_size, self.out_dim)
        x_mm = torch.relu(x_mm)
        return x_mm
    
    def gated_fusion(self, emb, rel):
        # emb: batch_size x dim
        # rel: batch_size x dim
        w = torch.sigmoid(emb * rel)
        return w * emb + (1 - w) * rel

class PrismF(BaseModel):
    def __init__(self, args):
        super(PrismF, self).__init__(args)
        self.entity_embeddings = nn.Embedding(
            len(args.entity2id),
            args.dim,
            padding_idx=None
        )
        nn.init.xavier_normal_(self.entity_embeddings.weight)

        self.relation_embeddings = nn.Embedding(
            2 * len(args.relation2id), 
            args.r_dim, 
            padding_idx=None
        )
        nn.init.xavier_normal_(self.relation_embeddings.weight)

        if args.pre_trained:
            self.entity_embeddings = nn.Embedding.from_pretrained(
                torch.from_numpy(pickle.load(open('datasets/' + args.dataset + '/gat_entity_vec.pkl', 'rb'))).float(), freeze=False)
            self.relation_embeddings = nn.Embedding.from_pretrained(torch.cat((
                torch.from_numpy(pickle.load(open('datasets/' + args.dataset + '/gat_relation_vec.pkl', 'rb'))).float(),
                -1 * torch.from_numpy(pickle.load(open('datasets/' + args.dataset + '/gat_relation_vec.pkl', 'rb'))).float()), dim=0), freeze=False)

        self.rel_gate = nn.Embedding(2 * len(args.relation2id), 1, padding_idx=None)

        if args.dataset == "DB15K":
            img_pool = torch.nn.AvgPool2d(4, stride=4)
            img = img_pool(args.img.to(self.device).view(-1, 64, 64))
            img = img.view(img.size(0), -1)
            txt_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            txt = txt_pool(args.desp.to(self.device).view(-1, 12, 64))
            txt = txt.view(txt.size(0), -1)
        elif "MKG" in args.dataset:
            # multi-modal information for MKG
            img = args.img.to(self.device).view(args.img.size(0), -1)
            txt_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            txt = txt_pool(args.desp.to(self.device).view(-1, 12, 32))
            txt = txt.view(txt.size(0), -1)
        elif "TIVA" in args.dataset:
            img_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            img = img_pool(args.img.to(self.device).view(-1, 32, 64))
            img = img.view(img.size(0), -1)
            txt = args.desp.to(self.device)
            txt = txt.view(txt.size(0), -1)
        elif "Kuai" in args.dataset:
            img_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            img = img_pool(args.img.to(self.device).view(-1, 12, 64))
            img = img.view(img.size(0), -1)
            txt_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            txt = txt_pool(args.desp.to(self.device).view(-1, 12, 64))
            txt = txt.view(txt.size(0), -1)
        elif "WN9" in args.dataset:
            img_pool = torch.nn.AvgPool2d(4, stride=4)
            img = img_pool(args.img.to(self.device).view(-1, 64, 64))
            img = img.view(img.size(0), -1)
            img = torch.tensor(img).to(torch.float32)
            txt = args.desp.to(self.device)
            txt = txt.view(txt.size(0), -1)
            txt = torch.tensor(txt).to(torch.float32)
        elif "FB15K-237" in args.dataset:
            img_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            img = img_pool(args.img.to(self.device).view(-1, 12, 64))
            img = img.view(img.size(0), -1)
            txt_pool = torch.nn.AdaptiveAvgPool2d(output_size=(4, 64))
            txt = txt_pool(args.desp.to(self.device).view(-1, 12, 64))
            txt = txt.view(txt.size(0), -1)

        self.img_entity_embeddings = nn.Embedding.from_pretrained(img, freeze=False)
        self.img_relation_embeddings = nn.Embedding(
            2 * len(args.relation2id),
            args.r_dim, 
            padding_idx=None
        )
        nn.init.xavier_normal_(self.img_relation_embeddings.weight)
        self.txt_entity_embeddings = nn.Embedding.from_pretrained(txt, freeze=False)
        self.txt_relation_embeddings = nn.Embedding(
            2 * len(args.relation2id),
            args.r_dim,
            padding_idx=None
        )
        nn.init.xavier_normal_(self.txt_relation_embeddings.weight)

        # Score Functions
        self.dim = args.dim
        self.img_dim = self.img_entity_embeddings.weight.data.shape[1]
        self.txt_dim = self.txt_entity_embeddings.weight.data.shape[1]
        self.fuse_out_dim = self.dim
        # Score function layers
        self.TuckER_S = TuckERLayer(args.dim, args.r_dim)
        self.TuckER_I = TuckERLayer(self.img_dim, args.r_dim)
        self.TuckER_D = TuckERLayer(self.txt_dim, args.r_dim)
        self.TuckER_MM = TuckERLayer(args.dim, self.fuse_out_dim)
        # Multi-modal fusion layers

        self.visual_feature = MuPELayer(n_pers=args.n_per, layers=[self.img_dim, self.img_dim])
        self.text_feature = MuPELayer(n_pers=args.n_per, layers=[self.txt_dim, self.txt_dim])
        self.structure_feature = MuPELayer(n_pers=args.n_per, layers=[self.dim, self.dim])
        self.mm_feature = MuPELayer(n_pers=args.n_per, layers=[self.fuse_out_dim, self.fuse_out_dim])
    
        self.fuse_e = PMFusionLayer(
            in_dim=args.dim,
            out_dim=self.fuse_out_dim,
            multi=2,
            img_dim=self.img_dim,
            txt_dim=self.txt_dim
        )
        self.fuse_r = PMFusionLayer(
            in_dim=args.r_dim,
            out_dim=self.fuse_out_dim,
            multi=2,
            img_dim=args.r_dim,
            txt_dim=args.r_dim
        )
        self.bias = nn.Parameter(torch.zeros(len(args.entity2id)))
        self.bceloss = nn.BCEWithLogitsLoss()
        

        self.log_vars = nn.Parameter(torch.zeros(4))

    def forward(self, batch_inputs, progress=1.0):
        head = batch_inputs[:, 0]
        relation = batch_inputs[:, 1]
        rel_gate = self.rel_gate(relation)

        e_embed, disen_str, atten_s = self.structure_feature(self.entity_embeddings(head), rel_gate)
        r_embed = self.relation_embeddings(relation)
        e_img_embed, disen_img, atten_i = self.visual_feature(self.img_entity_embeddings(head), rel_gate)
        r_img_embed = self.img_relation_embeddings(relation)
        e_txt_embed, disen_txt, atten_t = self.text_feature(self.txt_entity_embeddings(head), rel_gate)
        r_txt_embed = self.txt_relation_embeddings(relation)
        
        e_mm_embed, attn_f = self.fuse_e(e_embed, e_img_embed, e_txt_embed, progress=progress)
        r_mm_embed, _ = self.fuse_r(r_embed, r_img_embed, r_txt_embed, progress=progress)
        e_mm_embed = F.layer_norm(e_mm_embed, [self.fuse_out_dim])
        r_mm_embed = F.layer_norm(r_mm_embed, [self.fuse_out_dim])
        
        pred_s = self.TuckER_S(e_embed, r_embed)
        pred_i = self.TuckER_I(e_img_embed, r_img_embed)
        pred_d = self.TuckER_D(e_txt_embed, r_txt_embed)
        pred_mm = self.TuckER_MM(e_mm_embed, r_mm_embed)

        all_s, _, _ = self.structure_feature(self.entity_embeddings.weight)
        all_v, _, _ = self.visual_feature(self.img_entity_embeddings.weight)
        all_t, _, _ = self.text_feature(self.txt_entity_embeddings.weight)
        all_f, _ = self.fuse_e(all_s, all_v, all_t, progress=progress)

        pred_s = torch.mm(pred_s, all_s.transpose(1, 0))
        pred_i = torch.mm(pred_i, all_v.transpose(1, 0))
        pred_d = torch.mm(pred_d, all_t.transpose(1, 0))
        pred_mm = torch.mm(pred_mm, all_f.transpose(1, 0))

        if not self.training:
            pred_s = torch.sigmoid(pred_s)
            pred_i = torch.sigmoid(pred_i)
            pred_d = torch.sigmoid(pred_d)
            pred_mm = torch.sigmoid(pred_mm)
            return [pred_s, pred_i, pred_d, pred_mm], [atten_s, atten_i, atten_t, attn_f]
        else:
            return [pred_s, pred_i, pred_d, pred_mm], [disen_str, disen_img, disen_txt]
    
    def get_batch_embeddings(self, batch_inputs):
        head = batch_inputs[:, 0]
        _, disen_str, _ = self.structure_feature(self.entity_embeddings(head))
        _, disen_img, _ = self.visual_feature(self.img_entity_embeddings(head))
        _, disen_txt, _ = self.text_feature(self.txt_entity_embeddings(head))
        return [disen_str, disen_img, disen_txt]


    def loss_func(self, output, target):
        loss_s = self.bceloss(output[0], target)
        loss_i = self.bceloss(output[1], target)
        loss_d = self.bceloss(output[2], target)
        loss_mm = self.bceloss(output[3], target)
        return loss_s + loss_i + loss_d + loss_mm
